from setuptools import setup

setup(
    name='SKGEzhil_Voice_Assistant',
    version='1.0',
    packages=['SKGEzhil_Voice_Assistant'],
    url='https://github.com/SKGEzhil/SKGEzhil_Voice_Assistant',
    license='',
    author='SKGEzhil',
    author_email='skgezhil2005@gmail.com',
    description='A simple voice assistant'
)
